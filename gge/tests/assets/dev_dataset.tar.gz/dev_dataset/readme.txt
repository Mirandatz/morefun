Based on imagenette2-160: https://github.com/fastai/imagenette

Our train partition      = the first 10 instances of their train partition
Our validation partition = the last  10 instances of their train partition
Our test partition       = the first 10 instances of their validation partition

